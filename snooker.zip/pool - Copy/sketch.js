
    
var Engine = Matter.Engine;
var World = Matter.World;
var Bodies = Matter.Bodies;
var Body = Matter.Body;

var engine;
var cueBall;
var walls;
var balls;
var borders;
var pockets;

var currentMode = "A"; // Default mode is A

var ballColors = [];
var cueColor = 255;
var checkCueBall = false;

var cueBallPlaced = false;

var noForceLine = false;
var noForceLine = false;
var chameleon = false;
var invisibility = false;
var teleport = false;
var slowMotion = false;
var extendedGuide = false;
var bigCue = false;
var targetPosition;

var sizeOfCue = 8;
var forceMagnitude = 18000;

var lastPocketedColor = 0; // array to store the color of the last pocketed ball


function setup() {
    createCanvas(800, 500);
    engine = Engine.create();
    engine.world.gravity.y = 0;

    balls = [];
    walls = [];
    borders = [];
    wall_borders = [];
    pockets = [[20, 20], [400, 20], [780, 20], [20, 480], [400, 480], [780, 480]];
    generateCueBall();
    
    // Set the initial position of the cue ball (adjust coordinates as needed)
    Body.setPosition(cueBall, { x: width / 2 - 250, y: height / 2 });
    

    // Generate balls based on the current mode
    generateBallsA();
    setupWalls();
    
    // Initialize ball colors 
    initBallColors();
    

}

function draw() {
     
    background(59, 109, 35);
    Engine.update(engine);

    drawStartLine();
    drawWalls();
    drawCueBall();
    drawForceLine();
    drawBalls();
    drawPockets();
    
    specialAbilities();
    // Display instructions below the canvas
    fill(0);
    textSize(18);
    textAlign(LEFT, TOP);
    text('Press 1 for Mode A, 2 for Mode B, 3 for Mode C', 30, 30);
   
}

function keyPressed() {
    // Check which key is pressed
    if (key === '1') {
        // Switch to mode A
        resetBalls();
        generateBallsA();
    } else if (key === '2') {
        // Switch to mode B
        resetBalls();
        generateBallsB();
    } else if (key === '3') {
        // Switch to mode C
        resetBalls();
        generateBallsC();
    } else if (key === 'a'){
        noForceLine = true;
    } else if (key === 's'){
        chameleon = true;
    } else if (key === 'd'){
        invisibility = true;
    } else if (key === 'f'){
        teleport = true;
    } else if (key === 'g'){
        slowMotion = true;
    } else if (key === 'h'){
        extendedGuide = true;
    } else if (key === 'j'){
        bigCue = true;
    } else if (key === 'r'){
        noForceLine = false;
        multiBall = false;
        invisibility = false;
        teleport = false;
        slowMotion = false;
        extendedGuide = false;
        bigCue = false;
        cueColor = 255;
    }
    
    
}

function specialAbilities(){
    if (chameleon == true){
        var randomIndex = floor(random(ballColors.length));
        cueColor = ballColors[randomIndex];
        chameleon = false;

    }

    if (invisibility == true){
        cueBall.render.visible = false;
        
    
    }
    if (invisibility == false){
        cueBall.render.visible = true;
    }
    
    
    if (slowMotion == true){
        forceMagnitude += 500;
        
    }
    if (slowMotion == false){
        forceMagnitude = 18000;
    }
    
    if (bigCue == true){
        sizeOfCue = 15;
    }
    
    if(bigCue == false){
        sizeOfCue = 8;
    }
}
function resetBalls() {
    // Remove existing balls from the Matter.js world
    for (var i = 0; i < balls.length; i++) {
        World.remove(engine.world, balls[i]);
    }

    // Reset the balls array
    balls = [];
}

function initBallColors() {
    
    // Initialize ball colors for Mode A (red)
    for (var i = 0; i < balls.length; i++) {
        if(i<15){
            ballColors.push(color(255, 0, 0));
        }
        else if(i == 15){
            ballColors.push(color(255, 255, 0));
        }
        else if(i == 16){
            ballColors.push(color(0, 153, 0));
        }
        else if(i == 17){
            ballColors.push(color(255, 128, 0));
        }   
        else if(i == 18){
            ballColors.push(color(0, 0, 255));
        }
        else if(i == 19){
            ballColors.push(color(255, 153, 255));
        }
        else if(i == 20){
            ballColors.push(color(0, 0, 0));
        }

        
        
    }
    
    
}


function generateBallsA() {
    balls = []; // Reset the balls array
    
    // Add balls in the specified arrangement
    balls.push(Matter.Bodies.circle(width / 1.34, 240, 8, { restitution: 0.5, friction: 0.2 }));
    balls.push(Matter.Bodies.circle(width / 1.30, 230, 8, { restitution: 0.5, friction: 0.2 }));
    balls.push(Matter.Bodies.circle(width / 1.26, 220, 8, { restitution: 0.5, friction: 0.2 }));
    balls.push(Matter.Bodies.circle(width / 1.23, 210, 8, { restitution: 0.5, friction: 0.2 }));
    balls.push(Matter.Bodies.circle(width / 1.20, 200, 8, { restitution: 0.5, friction: 0.2 }));

    balls.push(Matter.Bodies.circle(width / 1.30, 230 + 22, 8, { restitution: 0.5, friction: 0.2 }));
    balls.push(Matter.Bodies.circle(width / 1.26, 220 + 22, 8, { restitution: 0.5, friction: 0.2 }));
    balls.push(Matter.Bodies.circle(width / 1.23, 210 + 22, 8, { restitution: 0.5, friction: 0.2 }));
    balls.push(Matter.Bodies.circle(width / 1.20, 200 + 22, 8, { restitution: 0.5, friction: 0.2 }));

    balls.push(Matter.Bodies.circle(width / 1.26, 220 + 44, 8, { restitution: 0.5, friction: 0.2 }));
    balls.push(Matter.Bodies.circle(width / 1.23, 210 + 44, 8, { restitution: 0.5, friction: 0.2 }));
    balls.push(Matter.Bodies.circle(width / 1.20, 200 + 44, 8, { restitution: 0.5, friction: 0.2 }));

    balls.push(Matter.Bodies.circle(width / 1.23, 210 + 66, 8, { restitution: 0.5, friction: 0.2 }));
    balls.push(Matter.Bodies.circle(width / 1.20, 200 + 66, 8, { restitution: 0.5, friction: 0.2 }));

    balls.push(Matter.Bodies.circle(width / 1.20, 200 + 88, 8, { restitution: 0.5, friction: 0.2 }));
    
    balls.push(Matter.Bodies.circle(180, 325, 8, { restitution: 0.5, friction: 0.2 })); //yellow ball
    balls.push(Matter.Bodies.circle(180, 175, 8, { restitution: 0.5, friction: 0.2 })); //green ball
    balls.push(Matter.Bodies.circle(width/2-220, height/2, 8, {restitution:0.5, friction:0.2})); //orange ball
    
    balls.push(Matter.Bodies.circle(width/2 , height/2, 8, {restitution:0.5, friction:0.2})); //blue ball
    
    balls.push(Matter.Bodies.circle(width / 1.39, 240, 8, { restitution: 0.5, friction: 0.2 })); //pink ball
    
    balls.push(Matter.Bodies.circle(width / 1.10, 200 + 44, 8, { restitution: 0.5, friction: 0.2 })); //black ball

   
   
    // Add balls to the Matter.js world
    World.add(engine.world, balls);
    
    for (var i = 0; i < balls.length; i++) {
        balls[i].render.fillStyle = ballColors[i];
    }
}

function generateBallsB() {
    balls = []; // Reset the balls array

    // Generate random positions for 15 balls
    for (var i = 0; i < 15; i++) {
        var ball = Bodies.circle(random(50, width - 50), random(50, height - 50), 8, {
            restitution: 0.5,
            friction: 0.2,
            render: {
                visible: true,
            }
        });
        balls.push(ball);
    }
    
    balls.push(Matter.Bodies.circle(180, 325, 8, { restitution: 0.5, friction: 0.2 })); //yellow ball
    balls.push(Matter.Bodies.circle(180, 175, 8, { restitution: 0.5, friction: 0.2 })); //green ball
    balls.push(Matter.Bodies.circle(width/2-220, height/2, 8, {restitution:0.5, friction:0.2})); //orange ball
    
    balls.push(Matter.Bodies.circle(width/2 , height/2, 8, {restitution:0.5, friction:0.2})); //blue ball
    
    balls.push(Matter.Bodies.circle(width / 1.39, 240, 8, { restitution: 0.5, friction: 0.2 })); //pink ball
    
    balls.push(Matter.Bodies.circle(width / 1.10, 200 + 44, 8, { restitution: 0.5, friction: 0.2 })); //black ball


    // Add balls to the Matter.js world
    World.add(engine.world, balls);
    
    
    for (var i = 0; i < balls.length; i++) {
        balls[i].render.fillStyle = ballColors[i];
    }
    
    
}

function generateBallsC() {
    balls = []; // Reset the balls array

    // Generate random positions for 15 balls
    for (var i = 0; i < 20; i++) {
        var ball = Bodies.circle(random(50, width - 50), random(50, height - 50), 8, {
            restitution: 0.5,
            friction: 0.2,
            render: {
                visible: true,
            }
        });
        balls.push(ball);
    }
    
   

    // Add balls to the Matter.js world
    World.add(engine.world, balls);
    
    for (var i = 0; i < balls.length; i++) {
        balls[i].render.fillStyle = ballColors[i];
    }
    
    
}

function drawBalls() {
    noStroke();
    fill(255, 0, 0);

    var ballToRemoveIndex = checkDistance(); // Get the index of the ball to remove

    for (var i = 0; i < balls.length; i++) {
        var ball = balls[i];

        if (i == ballToRemoveIndex) { 
            if (ballToRemoveIndex == 15) {
                Body.setPosition(balls[15], { x: 180, y: 325 });
                Body.setVelocity(balls[15], { x: 0, y: 0 });
                Body.setAngularVelocity(balls[15], 0);
                
            }

   
            else if (ballToRemoveIndex == 16){
                Body.setPosition(balls[16], { x: 180, y: 175 });
                Body.setVelocity(balls[16], { x: 0, y: 0 });
                Body.setAngularVelocity(balls[16], 0);
                
            }
            else if (ballToRemoveIndex == 17){
                Body.setPosition(balls[17], { x: width/2-220, y: height/2 });
                Body.setVelocity(balls[17], { x: 0, y: 0 });
                Body.setAngularVelocity(balls[17], 0);
                
                
            }
            else if (ballToRemoveIndex == 18){
                Body.setPosition(balls[18], { x: width/2, y: height/2 });
                Body.setVelocity(balls[18], { x: 0, y: 0 });
                Body.setAngularVelocity(balls[18], 0);
                
                
            }
            else if (ballToRemoveIndex == 19){
                Body.setPosition(balls[19], { x: width / 1.39, y: 240 });
                Body.setVelocity(balls[19], { x: 0, y: 0 });
                Body.setAngularVelocity(balls[19], 0);
                
                
            }
            else if (ballToRemoveIndex == 20){
                Body.setPosition(balls[20], { x: width / 1.10, y: 200 + 44 });
                Body.setVelocity(balls[20], { x: 0, y: 0 });
                Body.setAngularVelocity(balls[20], 0);
                
                
                
            }
            
            else{
                
                console.log('Removing ball:', ball);
            
                ballColors.splice(i,1);
                console.log(i);
                console.log(ballColors);
                console.log(balls);

                // Remove the current ball from the Matter.js world
                World.remove(engine.world, ball);

                // Remove the current ball from the array
                balls.splice(i, 1);

                ball.render.visible = false; // Hide the current ball

                console.log('Balls after removal:', balls);
                // Optionally, you might want to break out of the loop if only one ball should disappear
                // break;
            }
            
            
            
        }

        // Check if the ball is going out of bounds and adjust its position
        var buffer = 5; // Set a small buffer to move away from the boundary
        var leftBoundary = 10 + buffer;
        var rightBoundary = width - 10 - buffer;
        var topBoundary = 10 + buffer;
        var bottomBoundary = height - 10 - buffer;

        // Ensure the ball stays within the boundaries
        ball.position.x = constrain(ball.position.x, leftBoundary, rightBoundary);
        ball.position.y = constrain(ball.position.y, topBoundary, bottomBoundary);
        
        // Draw the ball with its assigned color
        fill(ballColors[i]);
        // Draw the ball if it's still visible
        if (ball.render.visible) {
            ellipse(ball.position.x, ball.position.y, ball.circleRadius * 2, ball.circleRadius * 2);
        }
    }
}

function drawPockets(){
    fill(0);   
    for (var i = 0; i < pockets.length; i++){
        ellipse(pockets[i][0], pockets[i][1], 20, 20);
    }
}


function drawStartLine(){
    stroke(255);
    line(180, 0, 180, 500);
    noFill();
    arc(180, 250, 150, 150, PI+300.02, TWO_PI+300.02,PIE);
    
}


function setupWalls(){
    var wall1 = Bodies.rectangle(450, 492, 900, 15, {isStatic:true});
    var wall2 = Bodies.rectangle(450, 8, 900, 15, {isStatic:true});
    var wall3 = Bodies.rectangle(8, 150, 15, 900, {isStatic:true});
    var wall4 = Bodies.rectangle(792, 150, 15, 900, {isStatic:true});
    
    var border1 = Bodies.rectangle(0, 0, 60, 31, {isStatic:true});
    var border2 = Bodies.rectangle(0, 0, 31, 60, {isStatic:true});
    var border3 = Bodies.rectangle(400, 0, 20, 31, {isStatic:true});
    var border4 = Bodies.rectangle(800, 0, 60, 31, {isStatic:true});
    var border5 = Bodies.rectangle(800, 0, 31, 60, {isStatic:true});
    var border6 = Bodies.rectangle(0, 500, 31, 60, {isStatic:true});
    var border7 = Bodies.rectangle(0, 500, 60, 31, {isStatic:true});
    var border8 = Bodies.rectangle(400, 500, 20, 31, {isStatic:true});
    var border9 = Bodies.rectangle(800, 500, 60, 31, {isStatic:true});
    var border10 = Bodies.rectangle(800, 500, 31, 60, {isStatic:true});
    
    var wall_border1 = Bodies.trapezoid(210, 490, 405, 25, 0.15, {isStatic:true});
    var wall_border2 = Bodies.trapezoid(590, 490, 405, 25, 0.15, {isStatic:true});
    var wall_border3 = Bodies.trapezoid(790, 250, 497, 25, 0.15, {isStatic:true, angle: Math.PI * 1.5});
    var wall_border4 = Bodies.trapezoid(10, 250, 422, 25, -0.15, {isStatic:true, angle: Math.PI * 1.5});
    var wall_border5 = Bodies.trapezoid(210, 10, 350, 25, -0.15, {isStatic:true});
    var wall_border6 = Bodies.trapezoid(590, 10, 350, 25, -0.15, {isStatic:true});



    
    walls.push(wall1);
    walls.push(wall2);
    walls.push(wall3);
    walls.push(wall4);
    World.add(engine.world,[wall1,wall2,wall3,wall4]);
    borders.push(border1);
    borders.push(border2);
    borders.push(border3);
    borders.push(border4);
    borders.push(border5);
    borders.push(border6);
    borders.push(border7);
    borders.push(border8);
    borders.push(border9);
    borders.push(border10);
    World.add(engine.world,[border1,border2,border3,border4,border5,border6,border7,border8,border9,border10]);
    wall_borders.push(wall_border1);
    wall_borders.push(wall_border2);
    wall_borders.push(wall_border3);
    wall_borders.push(wall_border4);
    wall_borders.push(wall_border5);
    wall_borders.push(wall_border6);

    

    World.add(engine.world, [wall_border1, wall_border2, wall_border3, wall_border4, wall_border5, wall_border6]);
    
    
    // Create invisible boundary walls around the canvas
    var boundaryLeft = Bodies.rectangle(-10, height / 2, 20, height, { isStatic: true });
    var boundaryRight = Bodies.rectangle(width + 10, height / 2, 20, height, { isStatic: true });
    var boundaryTop = Bodies.rectangle(width / 2, -10, width, 20, { isStatic: true });
    var boundaryBottom = Bodies.rectangle(width / 2, height + 10, width, 20, { isStatic: true });

    World.add(engine.world, [boundaryLeft, boundaryRight, boundaryTop, boundaryBottom]);

    
}

function drawWalls(){
    fill(0);
    for(var k = 0; k < wall_borders.length; k++){
        drawVertices(wall_borders[k].vertices);
    }
    fill(67,36,9);
    noStroke();
    for(var i = 0; i < walls.length; i++){
        drawVertices(walls[i].vertices);
    }
    fill(240,222,53);
    noStroke();
    for(var j = 0; j < borders.length; j++){
        drawVertices(borders[j].vertices);
    }
    
    
}



function generateCueBall(){
    cueBall = Bodies.circle(width/2-250, height/2, sizeOfCue, {
        restitution:0.8, 
        friction:.2,
        render: {
            visible: true,
        }
    });
    World.add(engine.world,[cueBall]);
}



function drawCueBall() {
    
    
    checkCueBallDistance();
    fill(cueColor);
    noStroke();
    
    
    if (cueBall.render.visible) {
        ellipse(cueBall.position.x, cueBall.position.y, sizeOfCue*2, sizeOfCue*2);
    }
}



function drawForceLine(){
    stroke(255);
    if (cueBallPlaced && !noForceLine && !extendedGuide){
        line(mouseX, mouseY, cueBall.position.x, cueBall.position.y);
    }
    if (extendedGuide){
        var lineLength = 10; // Adjust the length of the guideline
        var endX = cueBall.position.x + (mouseX + cueBall.position.x) * lineLength;
        var endY = cueBall.position.y + (mouseY + cueBall.position.y) * lineLength;
        line(cueBall.position.x, cueBall.position.y, endX, endY);
        console.log('line');
    }
}

    




function mousePressed() {
    
    if (!cueBallPlaced) {
        World.add(engine.world, cueBall);
        // Set the position of the cue ball to the mouse position
        Body.setPosition(cueBall, { x: mouseX, y: mouseY });
        // Set velocity and angular velocity to zero to prevent rolling
        Body.setVelocity(cueBall, { x: 0, y: 0 });
        Body.setAngularVelocity(cueBall, 0);
        cueBallPlaced = true;
        cueBall.render.visible = true;
        checkCueBall = false;
        
        

    } else {
        if (!checkCueBall) {
            // Calculate the force components
            
            var forceX = (cueBall.position.x - mouseX) / forceMagnitude;
            var forceY = (cueBall.position.y - mouseY) / forceMagnitude;

            var appliedForce = { x: forceX, y: forceY };

            // Apply force to the cue ball
            Body.applyForce(cueBall, cueBall.position, appliedForce);

            // Additional logic if needed
        }
    }
    

    // Check if the cue ball is going out of bounds and adjust its position
    var buffer = 5; // Set a small buffer to move away from the boundary
    if (cueBall.position.x < 10) {
        // Move the cue ball away from the boundary
        Body.setPosition(cueBall, { x: 10 + buffer, y: cueBall.position.y });
    } else if (cueBall.position.x > width - 10) {
        // Move the cue ball away from the boundary
        Body.setPosition(cueBall, { x: width - 10 - buffer, y: cueBall.position.y });
    }

    if (cueBall.position.y < 10) {
        // Move the cue ball away from the boundary
        Body.setPosition(cueBall, { x: cueBall.position.x, y: 10 + buffer });
    } else if (cueBall.position.y > height - 10) {
        // Move the cue ball away from the boundary
        Body.setPosition(cueBall, { x: cueBall.position.x, y: height - 10 - buffer });
    }
}


function checkDistance() {
    for (var i = 0; i < balls.length; i++) {
        var ball = balls[i];
        var x = ball.position.x;
        var y = ball.position.y;

        for (var j = 0; j < pockets.length; j++) {
            var pocketX = pockets[j][0];
            var pocketY = pockets[j][1];

            var dist = Math.sqrt((x - pocketX) ** 2 + (y - pocketY) ** 2);
            if (dist < 20) {
                console.log('Ball near pocket. Index:', i);
                // Check if the pocketed ball is colored
                if (i >= 15 && i <= 20) {
                    lastPocketedColor += 1;
                    if (lastPocketedColor == 2){
                        alert('Two consecutive colored balls fell into the pocket!');
                    }
                }
                else {
                    // Reset lastPocketedColor for non-colored balls
                    lastPocketedColor = 0;
                }

                return i; // Return the index of the ball near the pocket
            }
        }
    }

    return -1;
}


function checkCueBallDistance() {
    
    var x = cueBall.position.x;
    var y = cueBall.position.y;

    for (var j = 0; j < pockets.length; j++) {
        var pocketX = pockets[j][0];
        var pocketY = pockets[j][1];

        var dist = Math.sqrt((x - pocketX) ** 2 + (y - pocketY) ** 2);
        if (dist < 20) {
            console.log('cue pot');
            checkCueBall = true;
            World.remove(engine.world, cueBall);
            cueBall.render.visible = false;
            cueBallPlaced = false;
            console.log('remove cue');
        
        }   
    }
    
}
    


    




function drawVertices(vertices){
    beginShape();
    for (var i = 0; i < vertices.length; i++){
        vertex(vertices[i].x, vertices[i].y);
    }
    endShape(CLOSE);
}